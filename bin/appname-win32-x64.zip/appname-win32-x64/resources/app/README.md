## Para generar ejecutables. 

Windows:
```bash
npx  electron-packager . appname --platform=win32 --arch=x64 --out=./bin/
```

macOS (ejecutar como admin):

```bash
npx  electron-packager . appname --platform=darwin --arch=x64 --out=./bin/
```
